<html>
    <head>

    </head>
    <body>
        <script>
            window.location.href = "Assignment_18.1.php";
        </script>
    </body>
</html>