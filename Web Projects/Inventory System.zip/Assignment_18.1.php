<html>

<head>
    <title>
        Inventory System
    </title>
    <style>
        .heading {
            background-color: skyblue;
            font-size: 50px;
            border: 1px black solid;
            font-weight: bold;
            padding: 20px;
        }

        table {
            width: 100%;
            text-align: center;
            border: solid 1px;
            border-collapse: collapse;
        }

        .icons {
            width: 11.1%;
            border: 0px;
            padding: 10px;
        }

        td {
            border: solid 1px;
            width: 11.1%;
            padding: 5px;
            vertical-align: middle;
        }

        .body {
            width: 80%;
            margin: auto;
            padding: 20px;
            height: max-content;
        }

        input,
        button {
            width: 99%;
        }

        form {
            height: 6px;
        }

        img {
            height: 80px;
        }
    </style>



    <?php
    $conn = new mysqli("localhost", "root", "", "Syed");
    if ($conn->connect_error) {
        echo $conn->connect_error;
    }

    $conn->query("CREATE TABLE Items(Transaction_Code INT NOT NULL AUTO_INCREMENT PRIMARY KEY, Date VARCHAR(11), Item_Code INT(6), Item VARCHAR(20),  Quantity INT(2), Price INT(6), Total INT(6) )");

    $delete = $_GET["delete"];

    $tCode = $_GET["tCode"];
    $date = $_GET["date"];
    $iCode = $_GET["iCode"];
    $item = $_GET["item"];
    $quantity = $_GET["quantity"];
    $price = $_GET["price"];
    $total = $_GET["total"];

    $c_date = date("d/m/y");
    $c_iCode = $_GET["c_iCode"];
    $c_item = $_GET["c_item"];
    $c_quantity = $_GET["c_quantity"];
    $c_price = $_GET["c_price"];
    $c_total = $c_price * $c_quantity;

    if (isset($delete)) {
        $conn->query("DELETE FROM Items WHERE Transaction_Code = '$delete' ");
    }

    if (isset($tCode)) {
        $sql = "UPDATE Items SET 
        Date = '$date', 
        Item_Code = '$iCode', 
        Item = '$item', 
        Quantity = '$quantity', 
        Price = '$price', 
        Total = '$total' 
        WHERE Transaction_Code = '$tCode' ";

        $conn->query($sql);
    }

    if (isset($c_iCode)) {
        $sql = "INSERT Items SET 
        Date = '$c_date', 
        Item_Code = '$c_iCode', 
        Item = '$c_item', 
        Quantity = '$c_quantity', 
        Price = '$c_price', 
        Total = '$c_total' ";

        $conn->query($sql);

        header("Location: 18.1.redirect.php");
    }

    ?>

</head>

<body>
    <div class="heading">
        <span>SCSET @BU</span> <span style="float: right">INVENTORY SYSTEM</span>
    </div>
    <div>
        <table>
            <tr>
                <td class="icons"><img src="Items/items.jpg"></td>
                <td class="icons"><img src="Items/index.png"></td>
                <td class="icons"><img src="Items/sales.png"></td>
                <td class="icons"><img src="Items/account.png"></td>
                <td class="icons"><img src="Items/log.png"></td>
                <td class="icons"><img src="Items/backup.jpeg"></td>
                <td class="icons"><img src="Items/help.png"></td>
                <td class="icons"><img src="Items/change.png"></td>
                <td class="icons"><img src="Items/exit.png"></td>
            </tr>
            <tr>
                <td class="icons">ITEMS</td>
                <td class="icons">STOCKS</td>
                <td class="icons">SALES</td>
                <td class="icons">ACCOUNTS</td>
                <td class="icons">LOG MANAGER</td>
                <td class="icons">BACKUP DATABASE</td>
                <td class="icons">HELP</td>
                <td class="icons">CHANGE USER</td>
                <td class="icons">EXIT</td>
            </tr>
        </table>
        <form action="" method="get" id="create">
            <table>
                <tr>
                    <td colspan='2'><input type="text" name="c_iCode" placeholder="Item Code"></td>
                    <td colspan='2'><input type="text" name="c_item" placeholder="Item Name"></td>
                    <td colspan='2'><input type="text" name="c_quantity" placeholder="Quantity"></td>
                    <td colspan='2'><input type="text" name="c_price" placeholder="Price"></td>
                    <td><input type="submit" value="Add New"></td>
                </tr>
            </table>
        </form>
        <br><br><br>
        <div class="body">
            <table style="border: 0px;">
                <tr>
                    <td class="icons"><img src = "Items/summary.png"></td>
                    <td class="icons"><img src = "Items/daily.png"></td>
                    <td class="icons"><img src = "Items/monthly.png"></td>
                    <td class="icons"><img src = "Items/anually.png"></td>
                    <td class="icons" style="width: 33.3%;"></td>
                    <td rowspan="2" class="icons"><button style="height: 100px;width:100px;">Export</button></td>
                    <td rowspan="2" class="icons"><button style="height: 100px;width:100px;">Clear Transaction</button></td>
                </tr>
                <tr>
                    <td class="icons">Summary of Sales</td>
                    <td class="icons">Daily Sales</td>
                    <td class="icons">Monthly Sales</td>
                    <td class="icons">Annual Sales</td>
                    <td class="icons" style="width: 33.3%;"></td>
                </tr>
            </table>

            <table>
                <tr>
                    <td>Transaction Code</td>
                    <td>Date</td>
                    <td>Item Code</td>
                    <td>Item</td>
                    <td>Quantity</td>
                    <td>Price</td>
                    <td>Total</td>
                    <td>Update</td>
                    <td>Delete</td>
                </tr>
            </table>
            <?php

            $select = $conn->query("SELECT * from Items");
            if ($select->num_rows > 0) {
                while ($row = $select->fetch_assoc()) {
                    echo "<form method='GET'><table id = '" . $row["Transaction_Code"] . "'>";
                    echo "<tr>";
                    echo '<td>' . $row["Transaction_Code"] . '</td>';
                    echo '<td>' . $row["Date"] . '</td>';
                    echo '<td>' . $row["Item_Code"] . '</td>';
                    echo '<td>' . $row["Item"] . '</td>';
                    echo '<td>' . $row["Quantity"] . '</td>';
                    echo '<td>' . $row["Price"] . '</td>';
                    echo '<td>' . $row["Total"] . '</td>';
                    echo '<td><button onClick = updateRow("' . $row["Transaction_Code"] . '")>Update</button> </td>';
                    echo '<td><form method="GET"><button name="delete" type="submit" value="' . $row["Transaction_Code"] . '">Delete</button></form></td>';
                    echo "</tr></table></form>";
                }
            }

            ?>

            </table>
        </div>

    </div>


    <script>
        function updateRow(rowId) {
            row = document.getElementById(rowId);
            console.log(row);
            row.innerHTML = "<tr>" +
                "<td><input type='text' name = 'tCode' value='" + row.rows[0].cells[0].innerText + "' readonly ></td>" +
                "<td><input type='text' name = 'date' value='" + row.rows[0].cells[1].innerText + "'></td>" +
                "<td><input type='text' name = 'iCode' value='" + row.rows[0].cells[2].innerText + "'></td>" +
                "<td><input type='text' name = 'item' value='" + row.rows[0].cells[3].innerText + "'></td>" +
                "<td><input type='text' name = 'quantity' value='" + row.rows[0].cells[4].innerText + "'></td>" +
                "<td><input type='text' name = 'price' value='" + row.rows[0].cells[5].innerText + "'></td>" +
                "<td><input type='text' name = 'total' value='" + row.rows[0].cells[6].innerText + "'></td>" +
                "<td><input type='submit' value = 'Update'></td><td></td></tr>";
        }
    </script>

</body>

</html>